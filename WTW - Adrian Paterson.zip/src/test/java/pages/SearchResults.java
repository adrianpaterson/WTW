package pages;

import java.util.List;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class SearchResults {

	WebDriver driver;

	@FindBy(how = How.CLASS_NAME, using = "coveo-sort-icon-descending")
	private WebElement sortButton;

	@FindBy(how = How.CLASS_NAME, using = "coveo-facet-value-caption")
	private List<WebElement> filterList;	

	@FindBy(how = How.CLASS_NAME, using = "coveo-breadcrumb-clear-all")
	private WebElement contentFilterClear;
	
	@FindBy(how = How.CLASS_NAME, using = "CoveoResult")
	private List<WebElement> resultList;

	public SearchResults(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	public void clickSortButton(String sortType ) {
		WebDriverWait wait = new WebDriverWait(driver, 10);
		wait.until(ExpectedConditions.elementToBeClickable(sortButton)).click();
	}

	public void filterContent(String filterType) {
		WebDriverWait wait = new WebDriverWait(driver, 10);
		wait.until(ExpectedConditions.visibilityOfAllElements(filterList));
		for (WebElement filter : filterList) {
			if(filter.getAttribute("innerHTML").contains(filterType)) {
				filter.click();
				break;
			}
		}
	}

	public void validateResultURLS(String URLToValidate) {
		WebDriverWait wait = new WebDriverWait(driver, 10);
		wait.until(ExpectedConditions.visibilityOf(contentFilterClear));
		wait = new WebDriverWait(driver, 10);
		wait.until(ExpectedConditions.visibilityOfAllElements(resultList));
		System.out.println(resultList.size() + " Results displayed:");
		for (WebElement result : resultList) {
			String URL = result.findElement(By.tagName("a")).getAttribute("href");
			System.out.println(URL);
			if(!URL.contains(URLToValidate)) {
				Assert.fail("URL: " + URL + " does start with " + URLToValidate);
			}
		}
	}
	
}
