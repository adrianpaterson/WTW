package pages;

import java.util.List;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Homepage {

	WebDriver driver;

	@FindBy(how = How.CSS, using = "iframe[title='TrustArc Cookie Consent Manager']")
	private WebElement cookiePolicy;

	@FindBy(how = How.CLASS_NAME, using = "call")
	private WebElement acceptCookies;	

	@FindBy(how = How.CLASS_NAME, using = "site-nav__utility-btn")
	private WebElement locationDropdown;
	
	@FindBy(how = How.CLASS_NAME, using = "sr-only")
	private WebElement currentLanguage;	

	@FindBy(how = How.CLASS_NAME, using = "site-nav__btn--search-menu")
	private WebElement searchButton;
	
	@FindBy(how = How.CLASS_NAME, using = "country-selector__accordion-item")
	private List<WebElement> regionsList;

	@FindBy(how = How.CLASS_NAME, using = "magic-box-input")
	private WebElement searchboxArea;
	
	@FindBy(how = How.ID, using = "region0")
	private WebElement countries;
	
	public Homepage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	public void closeCookiePopup() {
		WebDriverWait wait = new WebDriverWait(driver, 10);
		wait.until(ExpectedConditions.frameToBeAvailableAndSwitchToIt(cookiePolicy));
		wait.until(ExpectedConditions.visibilityOf(acceptCookies)).click();
		driver.switchTo().parentFrame();
	}
	
	public void openLocationDropdown() {
		WebDriverWait wait = new WebDriverWait(driver, 10);
		wait.until(ExpectedConditions.elementToBeClickable(locationDropdown)).click();
	}
	
	public void selectRegion(String region) {
	    // Switch could be expanded for other regions as required
		switch(region) {
	    case "Americas":
	    	regionsList.get(0).click();
	    	break;
	    default:
	    	System.out.println("Unknown region requested");
	    	break;
	    }
	}
	
	public void selectLanguage(String country, String language) {
		List<WebElement> languages = countries.findElements(By.tagName("h5"));
		for (WebElement element : languages) {
		    if(element.getText().contains(country))
		    {
	    		WebElement languageLink = element.findElement(By.xpath("./../following-sibling::*[1]//a"));
		    	if(languageLink.getAttribute("innerHTML").contains(language)) {
		    		languageLink.click();
		    		break;
		    	}
		    }
		 }
	}
	
    public void verifyLanguage(String country, String language) {
    	WebElement location = locationDropdown.findElement(By.xpath("./.."));
    	if (!location.getAttribute("innerHTML").contains(country) || !location.getAttribute("innerHTML").contains(language)) {
    		Assert.fail("Failed to set the language to " + country + ", " + language);
    	}
    }
    
    public void openSearchPanelAndSearch(String query) {
    	WebDriverWait wait = new WebDriverWait(driver, 10);
		wait.until(ExpectedConditions.elementToBeClickable(searchButton)).click();
		WebElement searchboxInput = searchboxArea.findElement(By.tagName("input"));
    	searchboxInput.sendKeys(query + Keys.RETURN);
    }
}
