package stepdefs;


import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import pages.Homepage;
import pages.SearchResults;

public class Definitions {

	protected static WebDriver driver;
	Homepage homepage;
	SearchResults search;
	
	@Before
    public void beforeScenario(){
		driver = new ChromeDriver();
    }
	
	@After
    public void afterScenario(){
        driver.close();
    }
	
	@Given("I open Chrome and navigate to the URL {string}")
	public void navigate_to_URL(String URL) throws InterruptedException {
        driver.get(URL);
        homepage = new Homepage(driver);
        homepage.closeCookiePopup();
	}

	@When("I open the language selection panel")
	public void open_language_selection_panel() {
		homepage.openLocationDropdown();
	}

	@When("I select the region {string}")
	public void select_region(String region) {
		homepage.selectRegion(region);
	}
	
	@When("I select the language {string} and {string}")
	public void select_language(String country, String language) {
		homepage.selectLanguage(country, language);
	}

	@Then("the site is set to {string} and {string}")
	public void check_site_language(String location, String language) {
		homepage.verifyLanguage(location, language);
	}
	
	@When("I search for {string}")
	public void search_for(String query) {
		homepage.openSearchPanelAndSearch(query);
		
	}

	@When("sort the results by {string}")
	public void sort_the_results_by(String sortType) {
		search = new SearchResults(driver);
		search.clickSortButton(sortType);
	}
	
	@When("filter the content type to {string}")
	public void filter_the_content_type_to(String filter) {
	    search.filterContent(filter);
	}

	@Then("I validate all the results contain links that start with {string}")
	public void i_validate_all_the_results_contain_links_that_start_with(String url) {
	    search.validateResultURLS(url);
	}
}
